import { defineRecipe } from "@chakra-ui/react";
//#region src/components/icon/recipe.ts
const iconRecipe = defineRecipe({
	className: "teleport-icon",
	base: {
		display: "inline-block",
		lineHeight: "1em",
		flexShrink: "0",
		color: "currentcolor",
		verticalAlign: "middle"
	},
	variants: { size: {
		inherit: {},
		xs: { boxSize: "3" },
		sm: { boxSize: "4" },
		md: { boxSize: "5" },
		lg: { boxSize: "6" },
		xl: { boxSize: "7" },
		"2xl": { boxSize: "8" }
	} },
	defaultVariants: { size: "inherit" }
});
//#endregion
export { iconRecipe };

//# sourceMappingURL=recipe.js.map